-- Create stored procedure for getting all products
CREATE PROCEDURE GetAllProducts
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT Id, Name, Price 
    FROM Products 
    ORDER BY Id;
END
GO

-- Create stored procedure for getting products with pagination
CREATE PROCEDURE GetProductsPaginated
    @PageNumber INT = 1,
    @PageSize INT = 10
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;
    
    SELECT Id, Name, Price 
    FROM Products 
    ORDER BY Id
    OFFSET @Offset ROWS
    FETCH NEXT @PageSize ROWS ONLY;
    
    -- Also return total count for pagination info
    SELECT COUNT(*) AS TotalCount FROM Products;
END
GO