using Microsoft.EntityFrameworkCore;
using ProductsAPI.Data;
using ProductsAPI.Models;
using ProductsAPI.Repositories;
using Xunit;

namespace ProductsAPI.Tests
{
    public class ProductRepositoryTests : IDisposable
    {
        private readonly ProductsDbContext _context;
        private readonly ProductRepository _repository;

        public ProductRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<ProductsDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ProductsDbContext(options);
            _repository = new ProductRepository(_context);

            // Seed test data
            SeedTestData();
        }

        private void SeedTestData()
        {
            var products = new List<Product>
            {
                new Product { Id = 1, Name = "Test Product 1", Price = 10.99m },
                new Product { Id = 2, Name = "Test Product 2", Price = 25.50m },
                new Product { Id = 3, Name = "Test Product 3", Price = 15.75m },
                new Product { Id = 4, Name = "Test Product 4", Price = 8.99m },
                new Product { Id = 5, Name = "Test Product 5", Price = 99.99m }
            };

            _context.Products.AddRange(products);
            _context.SaveChanges();
        }

        [Fact]
        public async Task GetAllProductsAsync_ReturnsAllProducts()
        {
            // Act
            var result = await _repository.GetAllProductsAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(5, result.Count());
        }

        [Fact]
        public async Task GetProductsPaginatedAsync_ReturnsCorrectPage()
        {
            // Arrange
            int page = 1;
            int pageSize = 3;

            // Act
            var result = await _repository.GetProductsPaginatedAsync(page, pageSize);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(pageSize, result.Items.Count());
            Assert.Equal(5, result.TotalCount);
            Assert.Equal(page, result.Page);
            Assert.Equal(pageSize, result.PageSize);
            Assert.Equal(2, result.TotalPages);
            Assert.True(result.HasNextPage);
            Assert.False(result.HasPreviousPage);
        }

        [Fact]
        public async Task GetProductsPaginatedAsync_ReturnsSecondPage()
        {
            // Arrange
            int page = 2;
            int pageSize = 3;

            // Act
            var result = await _repository.GetProductsPaginatedAsync(page, pageSize);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Items.Count()); // Only 2 items on second page
            Assert.Equal(5, result.TotalCount);
            Assert.Equal(page, result.Page);
            Assert.Equal(pageSize, result.PageSize);
            Assert.False(result.HasNextPage);
            Assert.True(result.HasPreviousPage);
        }

        [Fact]
        public async Task GetProductsPaginatedAsync_WithLargePageSize_ReturnsAllProducts()
        {
            // Arrange
            int page = 1;
            int pageSize = 100;

            // Act
            var result = await _repository.GetProductsPaginatedAsync(page, pageSize);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(5, result.Items.Count());
            Assert.Equal(5, result.TotalCount);
            Assert.Equal(1, result.TotalPages);
            Assert.False(result.HasNextPage);
            Assert.False(result.HasPreviousPage);
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}