using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ProductsAPI.Data;
using ProductsAPI.Models;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace ProductsAPI.Tests
{
    public class ProductsApiIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly WebApplicationFactory<Program> _factory;
        private readonly HttpClient _client;

        public ProductsApiIntegrationTests(WebApplicationFactory<Program> factory)
        {
            _factory = factory.WithWebHostBuilder(builder =>
            {
                builder.ConfigureServices(services =>
                {
                    // Remove the real database context
                    var descriptor = services.SingleOrDefault(
                        d => d.ServiceType == typeof(DbContextOptions<ProductsDbContext>));
                    if (descriptor != null)
                        services.Remove(descriptor);

                    // Add in-memory database for testing
                    services.AddDbContext<ProductsDbContext>(options =>
                    {
                        options.UseInMemoryDatabase("InMemoryDbForTesting");
                    });

                    // Build the service provider and seed test data
                    var sp = services.BuildServiceProvider();
                    using var scope = sp.CreateScope();
                    var scopedServices = scope.ServiceProvider;
                    var db = scopedServices.GetRequiredService<ProductsDbContext>();
                    
                    db.Database.EnsureCreated();
                    SeedTestData(db);
                });
            });

            _client = _factory.CreateClient();
        }

        private static void SeedTestData(ProductsDbContext context)
        {
            if (context.Products.Any())
                return;

            var products = new List<Product>
            {
                new Product { Id = 1, Name = "Test Product 1", Price = 10.99m },
                new Product { Id = 2, Name = "Test Product 2", Price = 25.50m },
                new Product { Id = 3, Name = "Test Product 3", Price = 15.75m },
                new Product { Id = 4, Name = "Test Product 4", Price = 8.99m },
                new Product { Id = 5, Name = "Test Product 5", Price = 99.99m }
            };

            context.Products.AddRange(products);
            context.SaveChanges();
        }

        [Fact]
        public async Task GetProducts_ReturnsSuccessAndCorrectContentType()
        {
            // Act
            var response = await _client.GetAsync("/api/products");

            // Assert
            response.EnsureSuccessStatusCode();
            Assert.Equal("application/json; charset=utf-8", 
                response.Content.Headers.ContentType?.ToString());
        }

        [Fact]
        public async Task GetProducts_ReturnsExpectedProducts()
        {
            // Act
            var response = await _client.GetAsync("/api/products");
            var jsonString = await response.Content.ReadAsStringAsync();
            var products = JsonSerializer.Deserialize<List<Product>>(jsonString, 
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            // Assert
            Assert.NotNull(products);
            Assert.Equal(5, products.Count);
            Assert.Contains(products, p => p.Name == "Test Product 1");
        }

        [Fact]
        public async Task GetProductsPaginated_ReturnsCorrectPage()
        {
            // Act
            var response = await _client.GetAsync("/api/products/paginated?page=1&pageSize=3");
            var jsonString = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<PaginatedResult<Product>>(jsonString,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            // Assert
            response.EnsureSuccessStatusCode();
            Assert.NotNull(result);
            Assert.Equal(3, result.Items.Count());
            Assert.Equal(5, result.TotalCount);
            Assert.Equal(1, result.Page);
            Assert.Equal(3, result.PageSize);
        }

        [Fact]
        public async Task GetProductsPaginated_WithInvalidParameters_ReturnsValidDefaults()
        {
            // Act
            var response = await _client.GetAsync("/api/products/paginated?page=-1&pageSize=200");
            var jsonString = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<PaginatedResult<Product>>(jsonString,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            // Assert
            response.EnsureSuccessStatusCode();
            Assert.NotNull(result);
            Assert.Equal(1, result.Page); // Should default to 1
            Assert.True(result.PageSize <= 100); // Should be constrained to max 100
        }

        [Fact]
        public async Task HomeIndex_ReturnsSuccessAndCorrectContentType()
        {
            // Act
            var response = await _client.GetAsync("/");

            // Assert
            response.EnsureSuccessStatusCode();
            Assert.Equal("text/html; charset=utf-8",
                response.Content.Headers.ContentType?.ToString());
        }

        [Fact]
        public async Task ProductsPage_ReturnsSuccessAndCorrectContentType()
        {
            // Act
            var response = await _client.GetAsync("/Home/Products");

            // Assert
            response.EnsureSuccessStatusCode();
            Assert.Equal("text/html; charset=utf-8",
                response.Content.Headers.ContentType?.ToString());
        }
    }
}