using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using ProductsAPI.Data;
using ProductsAPI.Models;
using System.Data;

namespace ProductsAPI.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductsDbContext _context;

        public ProductRepository(ProductsDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            try
            {
                // For in-memory database, use LINQ instead of stored procedures
                if (_context.Database.IsInMemory())
                {
                    return await _context.Products
                        .OrderBy(p => p.Id)
                        .ToListAsync();
                }

                // For SQL Server, use stored procedures
                return await _context.Products
                    .FromSqlRaw("EXEC GetAllProducts")
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error retrieving products from database", ex);
            }
        }

        public async Task<PaginatedResult<Product>> GetProductsPaginatedAsync(int page, int pageSize)
        {
            try
            {
                // For in-memory database, use LINQ instead of stored procedures
                if (_context.Database.IsInMemory())
                {
                    var totalProductCount = await _context.Products.CountAsync();
                    var pagedProducts = await _context.Products
                        .OrderBy(p => p.Id)
                        .Skip((page - 1) * pageSize)
                        .Take(pageSize)
                        .ToListAsync();

                    return new PaginatedResult<Product>
                    {
                        Items = pagedProducts,
                        TotalCount = totalProductCount,
                        Page = page,
                        PageSize = pageSize
                    };
                }

                // For SQL Server, use stored procedures
                var pageParam = new SqlParameter("@PageNumber", page);
                var pageSizeParam = new SqlParameter("@PageSize", pageSize);

                // Get products for the current page
                var products = await _context.Products
                    .FromSqlRaw("EXEC GetProductsPaginated @PageNumber, @PageSize", pageParam, pageSizeParam)
                    .ToListAsync();

                // Get total count
                var totalCountParam = new SqlParameter("@TotalCount", SqlDbType.Int) { Direction = ParameterDirection.Output };
                var totalCountQuery = "SELECT @TotalCount = COUNT(*) FROM Products";
                
                await _context.Database.ExecuteSqlRawAsync($"{totalCountQuery}", totalCountParam);
                var totalCount = (int)totalCountParam.Value;

                return new PaginatedResult<Product>
                {
                    Items = products,
                    TotalCount = totalCount,
                    Page = page,
                    PageSize = pageSize
                };
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error retrieving paginated products from database", ex);
            }
        }
    }
}