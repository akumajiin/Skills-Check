using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductsAPI.Models
{
    [Table("Products")]
    public class Product
    {
        [Key]
        public int Id { get; set; }

        [Column(TypeName = "NVARCHAR(100)")]
        public string Name { get; set; } = string.Empty;

        [Column(TypeName = "DECIMAL(10,2)")]
        public decimal Price { get; set; }
    }
}