# Products API

A complete ASP.NET Core Web API with MVC web interface for managing products from a SQL Server database.

## Features

- **RESTful API** with Swagger documentation
- **MVC Web Application** with responsive UI
- **Pagination** support for large datasets
- **Stored Procedures** for efficient data access
- **Comprehensive Error Handling** with structured logging
- **Unit & Integration Tests** for reliability
- **Repository Pattern** with dependency injection

## API Endpoints

- `GET /api/products` - Get all products
- `GET /api/products/paginated?page=1&pageSize=10` - Get paginated products
- `GET /swagger` - API documentation

## Web Pages

- `/` - Home page with product cards
- `/Home/Products` - Product list with table view

## Prerequisites

- .NET 6.0 or later
- SQL Server (LocalDB supported)
- Visual Studio 2022 or VS Code

## Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ProductsAPI
   ```

2. **Update connection string**
   Update `appsettings.json` with your SQL Server connection string

3. **Setup database**
   ```sql
   -- Create the Products table
   CREATE TABLE Products (
       Id INT PRIMARY KEY,
       Name NVARCHAR(100),
       Price DECIMAL(10,2)
   );
   
   -- Run stored procedures from SQL/StoredProcedures.sql
   ```

4. **Build and run the application**
   ```bash
   # Restore and build main project
   dotnet restore ProductsAPI.csproj
   dotnet build ProductsAPI.csproj
   dotnet run --project ProductsAPI.csproj
   ```

5. **Run tests (optional)**
   ```bash
   # Restore test dependencies first
   dotnet restore ProductsAPI.Tests/ProductsAPI.Tests.csproj
   dotnet test ProductsAPI.Tests/ProductsAPI.Tests.csproj --verbosity normal
   ```

6. **Or build everything together**
   ```bash
   # Add test project to solution and build all
   dotnet sln ProductsAPI.sln add ProductsAPI.Tests/ProductsAPI.Tests.csproj
   dotnet restore
   dotnet build
   dotnet test
   ```

## Project Structure

```
ProductsAPI/
├── Controllers/           # API and MVC controllers
├── Data/                 # Entity Framework DbContext
├── Models/               # Data models and DTOs
├── Repositories/         # Data access layer
├── Views/                # MVC views and layouts
├── SQL/                  # Database scripts
├── ProductsAPI.Tests/    # Unit and integration tests
└── README.md
```

## Configuration

The application uses SQL Server by default. Update the connection string in `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ProductsDB;Trusted_Connection=true;MultipleActiveResultSets=true"
  }
}
```

## Testing

The project includes comprehensive tests:

- **Unit Tests**: Repository and controller testing with mocks
- **Integration Tests**: Full API testing with in-memory database
- **Test Coverage**: Success scenarios, error handling, edge cases

Run tests with:
```bash
dotnet test ProductsAPI.Tests --verbosity normal
```

## Technologies Used

- **ASP.NET Core 6** - Web framework
- **Entity Framework Core** - ORM
- **SQL Server** - Database
- **xUnit** - Testing framework
- **Moq** - Mocking framework
- **Bootstrap 5** - UI framework
- **Swagger/OpenAPI** - API documentation

## Architecture

- **Repository Pattern** for data access abstraction
- **Dependency Injection** for loose coupling
- **Async/Await** for non-blocking operations
- **Structured Logging** for debugging and monitoring
- **Error Handling** with proper HTTP status codes

## API Response Examples

### Get All Products
```json
[
  {
    "id": 1,
    "name": "Product 1",
    "price": 10.99
  }
]
```

### Get Paginated Products
```json
{
  "items": [...],
  "totalCount": 100,
  "page": 1,
  "pageSize": 10,
  "totalPages": 10,
  "hasNextPage": true,
  "hasPreviousPage": false
}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

This project is licensed under the MIT License.