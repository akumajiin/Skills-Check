using Microsoft.AspNetCore.Mvc;
using ProductsAPI.Models;
using ProductsAPI.Repositories;

namespace ProductsAPI.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<HomeController> _logger;

        public HomeController(IProductRepository productRepository, ILogger<HomeController> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        public async Task<IActionResult> Index(int page = 1, int pageSize = 10)
        {
            try
            {
                _logger.LogInformation("Loading products page {Page} with page size {PageSize}", page, pageSize);
                
                var result = await _productRepository.GetProductsPaginatedAsync(page, pageSize);
                
                ViewBag.CurrentPage = page;
                ViewBag.PageSize = pageSize;
                
                return View(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading products page");
                ViewBag.Error = "Unable to load products. Please try again later.";
                return View(new PaginatedResult<Product>());
            }
        }

        public async Task<IActionResult> Products(int page = 1, int pageSize = 10)
        {
            try
            {
                var result = await _productRepository.GetProductsPaginatedAsync(page, pageSize);
                return View(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading products");
                ViewBag.Error = "Unable to load products. Please try again later.";
                return View(new PaginatedResult<Product>());
            }
        }
    }
}