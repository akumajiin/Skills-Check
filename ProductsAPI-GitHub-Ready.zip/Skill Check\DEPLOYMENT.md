# Deployment Guide

## Quick Deployment Steps

### 1. Database Setup
```sql
-- Create database
CREATE DATABASE ProductsDB;
GO

USE ProductsDB;
GO

-- Create Products table
CREATE TABLE Products (
    Id INT PRIMARY KEY,
    Name NVARCHAR(100),
    Price DECIMAL(10,2)
);
GO

-- Insert sample data
INSERT INTO Products (Id, Name, Price) VALUES
(1, 'Laptop Computer', 999.99),
(2, 'Wireless Mouse', 29.99),
(3, 'Mechanical Keyboard', 149.99),
(4, 'USB-C Hub', 79.99),
(5, 'External Monitor', 299.99);
GO

-- Execute stored procedures from SQL/StoredProcedures.sql
```

### 2. Configuration
Update the connection string in `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER;Database=ProductsDB;Trusted_Connection=true;MultipleActiveResultSets=true"
  }
}
```

### 3. Run Application
```bash
dotnet restore
dotnet build
dotnet run
```

### 4. Access Points
- **Web Interface**: https://localhost:5001
- **API Documentation**: https://localhost:5001/swagger
- **API Endpoint**: https://localhost:5001/api/products

## Production Deployment

### IIS Deployment
1. Publish the application: `dotnet publish -c Release -o ./publish`
2. Copy published files to IIS wwwroot
3. Configure IIS application pool for .NET 6
4. Update connection string for production database

### Docker Deployment
```dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:6.0 AS runtime
WORKDIR /app
COPY publish/ .
ENTRYPOINT ["dotnet", "ProductsAPI.dll"]
```

### Azure Deployment
1. Create Azure App Service
2. Configure connection string in Azure portal
3. Deploy using Visual Studio or Azure DevOps
4. Run database scripts in Azure SQL Database