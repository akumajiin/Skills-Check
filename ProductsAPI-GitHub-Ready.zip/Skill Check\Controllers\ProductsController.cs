using Microsoft.AspNetCore.Mvc;
using ProductsAPI.Models;
using ProductsAPI.Repositories;

namespace ProductsAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(IProductRepository productRepository, ILogger<ProductsController> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        /// <summary>
        /// Gets all products from the database
        /// </summary>
        /// <returns>A JSON array of all products</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            try
            {
                _logger.LogInformation("Fetching all products");
                var products = await _productRepository.GetAllProductsAsync();
                
                _logger.LogInformation("Successfully retrieved {ProductCount} products", products.Count());
                return Ok(products);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Database operation error while fetching products");
                return StatusCode(500, new { error = "Database error occurred", message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred while fetching products");
                return StatusCode(500, new { error = "An unexpected error occurred while retrieving products" });
            }
        }

        /// <summary>
        /// Gets paginated products from the database
        /// </summary>
        /// <param name="page">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10, max: 100)</param>
        /// <returns>A paginated result with products</returns>
        [HttpGet("paginated")]
        public async Task<ActionResult<PaginatedResult<Product>>> GetProductsPaginated(
            [FromQuery] int page = 1, 
            [FromQuery] int pageSize = 10)
        {
            try
            {
                // Validate pagination parameters
                if (page < 1)
                {
                    _logger.LogWarning("Invalid page number: {Page}. Using default value of 1", page);
                    page = 1;
                }

                if (pageSize < 1 || pageSize > 100)
                {
                    _logger.LogWarning("Invalid page size: {PageSize}. Using default value of 10", pageSize);
                    pageSize = Math.Min(Math.Max(pageSize, 1), 100);
                }

                _logger.LogInformation("Fetching products - Page: {Page}, PageSize: {PageSize}", page, pageSize);
                
                var result = await _productRepository.GetProductsPaginatedAsync(page, pageSize);
                
                _logger.LogInformation("Successfully retrieved {ProductCount} products out of {TotalCount} total", 
                    result.Items.Count(), result.TotalCount);
                
                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Database operation error while fetching paginated products");
                return StatusCode(500, new { error = "Database error occurred", message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred while fetching paginated products");
                return StatusCode(500, new { error = "An unexpected error occurred while retrieving products" });
            }
        }
    }
}