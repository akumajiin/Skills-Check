using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ProductsAPI.Controllers;
using ProductsAPI.Models;
using ProductsAPI.Repositories;
using Xunit;

namespace ProductsAPI.Tests
{
    public class ProductsControllerTests
    {
        private readonly Mock<IProductRepository> _mockRepository;
        private readonly Mock<ILogger<ProductsController>> _mockLogger;
        private readonly ProductsController _controller;

        public ProductsControllerTests()
        {
            _mockRepository = new Mock<IProductRepository>();
            _mockLogger = new Mock<ILogger<ProductsController>>();
            _controller = new ProductsController(_mockRepository.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task GetProducts_ReturnsOkResult_WithProducts()
        {
            // Arrange
            var expectedProducts = new List<Product>
            {
                new Product { Id = 1, Name = "Test Product 1", Price = 10.99m },
                new Product { Id = 2, Name = "Test Product 2", Price = 25.50m }
            };

            _mockRepository.Setup(repo => repo.GetAllProductsAsync())
                          .ReturnsAsync(expectedProducts);

            // Act
            var result = await _controller.GetProducts();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualProducts = Assert.IsAssignableFrom<IEnumerable<Product>>(okResult.Value);
            Assert.Equal(2, actualProducts.Count());
        }

        [Fact]
        public async Task GetProducts_ThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            _mockRepository.Setup(repo => repo.GetAllProductsAsync())
                          .ThrowsAsync(new Exception("Database error"));

            // Act
            var result = await _controller.GetProducts();

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(500, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task GetProductsPaginated_ReturnsOkResult_WithPaginatedData()
        {
            // Arrange
            var expectedResult = new PaginatedResult<Product>
            {
                Items = new List<Product>
                {
                    new Product { Id = 1, Name = "Test Product 1", Price = 10.99m }
                },
                TotalCount = 10,
                Page = 1,
                PageSize = 1
            };

            _mockRepository.Setup(repo => repo.GetProductsPaginatedAsync(1, 1))
                          .ReturnsAsync(expectedResult);

            // Act
            var result = await _controller.GetProductsPaginated(1, 1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResult = Assert.IsType<PaginatedResult<Product>>(okResult.Value);
            Assert.Equal(10, actualResult.TotalCount);
            Assert.Equal(1, actualResult.Page);
            Assert.Equal(1, actualResult.PageSize);
        }

        [Fact]
        public async Task GetProductsPaginated_WithInvalidPage_UsesDefaultValue()
        {
            // Arrange
            var expectedResult = new PaginatedResult<Product>
            {
                Items = new List<Product>(),
                TotalCount = 0,
                Page = 1,
                PageSize = 10
            };

            _mockRepository.Setup(repo => repo.GetProductsPaginatedAsync(1, 10))
                          .ReturnsAsync(expectedResult);

            // Act
            var result = await _controller.GetProductsPaginated(-1, 10);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResult = Assert.IsType<PaginatedResult<Product>>(okResult.Value);
            Assert.Equal(1, actualResult.Page);
        }

        [Fact]
        public async Task GetProductsPaginated_WithInvalidPageSize_UsesConstrainedValue()
        {
            // Arrange
            var expectedResult = new PaginatedResult<Product>
            {
                Items = new List<Product>(),
                TotalCount = 0,
                Page = 1,
                PageSize = 100
            };

            _mockRepository.Setup(repo => repo.GetProductsPaginatedAsync(1, 100))
                          .ReturnsAsync(expectedResult);

            // Act - Test with pageSize > 100
            var result = await _controller.GetProductsPaginated(1, 150);

            // Assert
            _mockRepository.Verify(repo => repo.GetProductsPaginatedAsync(1, 100), Times.Once);
        }

        [Fact]
        public async Task GetProductsPaginated_ThrowsInvalidOperationException_ReturnsSpecificError()
        {
            // Arrange
            var exception = new InvalidOperationException("Database connection failed");
            _mockRepository.Setup(repo => repo.GetProductsPaginatedAsync(It.IsAny<int>(), It.IsAny<int>()))
                          .ThrowsAsync(exception);

            // Act
            var result = await _controller.GetProductsPaginated(1, 10);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(500, statusCodeResult.StatusCode);
            
            dynamic errorResponse = statusCodeResult.Value!;
            Assert.Equal("Database error occurred", errorResponse.error);
            Assert.Equal("Database connection failed", errorResponse.message);
        }
    }
}